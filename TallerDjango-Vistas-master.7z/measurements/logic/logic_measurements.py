from ..models import Measurement


def get_all_measurements():
    measurements = Measurement.objects.all()
    return measurements


def get_justA_measurement(id):
    measuremtSalida = Measurement.objects.get(pk=id)
    return measuremtSalida


def del_justA_measurement(id):
    measuremtSalida = Measurement.objects.get(pk)
    Measurement.objects
    return measuremtSalida
