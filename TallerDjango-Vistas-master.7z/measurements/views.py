
from .logic.logic_measurements import get_all_measurements
from .logic.logic_measurements import get_justA_measurement
from django.http import  HttpResponse
from django.core import  serializers


def get_measurements(request):
    measurements = get_all_measurements()
    measurements_list = serializers.serialize('json', measurements)
    return HttpResponse(measurements_list,content_type='application/json')
def get_justone_Mesuarement(request):
    measurement_one = get_justA_measurement(request)
    return HttpResponse(measurement_one,content_type='application/json')
def Del_justone_Mesuarement(request):
    measurement_Delete = Delete_justA_measurement(request)
    return HttpResponse(measurement_one,content_type='application/json')
def get_justone_Mesuarement(request):
    measurement_one = get_justA_measurement(request)
    return HttpResponse(measurement_one,content_type='application/json')
